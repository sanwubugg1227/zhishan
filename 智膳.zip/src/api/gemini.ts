import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, FamilyMember, LocationData, DietPlan } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateDietPlan(
  user: UserProfile,
  family: FamilyMember[],
  location: LocationData | null,
  planType: "single" | "daily" | "weekly",
  preferences: string, // Extra user input like "I want something spicy today"
  language: string = "en",
): Promise<DietPlan> {
  const totalPeople = 1 + family.length;

  const prompt = `
    You are an expert nutritionist and chef. Create a personalized diet plan based on the following information:
    
    User Profile:
    - Age: ${user.age}, Gender: ${user.gender}, Height: ${user.height}cm, Weight: ${user.weight}kg
    - Activity Level: ${user.activityLevel}
    - Goal: ${user.goal}
    - Health Conditions: ${user.healthConditions.join(", ") || "None"}
    - Dietary Preferences: ${user.dietaryPreferences.join(", ") || "None"}
    - Allergies: ${user.allergies.join(", ") || "None"}
    
    Family Members (${family.length}):
    ${family.map((f) => `- ${f.name} (${f.age}yo, ${f.relation}): Preferences: ${f.dietaryPreferences.join(", ") || "None"}, Allergies: ${f.allergies.join(", ") || "None"}`).join("\n")}
    
    Total Servings Needed: ${totalPeople}
    
    Location: ${location ? `${location.city}, ${location.region}, ${location.country}` : "Unknown"}
    *If location is known, try to incorporate local seasonal vegetables or special ingredients, but also provide variety.*
    
    Plan Type: ${planType} (single meal, full day, or full week)
    Extra Preferences: ${preferences || "None"}
    
    Generate a detailed ${planType} diet plan. Ensure the meals are healthy, easy to make, and suitable for the whole family's dietary needs and allergies.
    
    CRITICAL INSTRUCTION: Strongly prefer authentic Chinese cuisine and local Chinese recipes. Avoid typical Western diets (like salads, sandwiches, pasta) unless specifically requested by the user. Use common Chinese ingredients and cooking methods (stir-frying, steaming, braising, etc.).
    Include a mix of local/seasonal ingredients if applicable.
    
    IMPORTANT: Please generate all text content (titles, descriptions, names, instructions, etc.) in ${language === "zh" ? "Chinese (Simplified)" : "English"}.
    
    Return the plan in JSON format matching the requested schema.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: {
            type: Type.STRING,
            description: "A catchy title for the diet plan",
          },
          days: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                date: {
                  type: Type.STRING,
                  description: "Day label, e.g., Day 1, Monday, or Today",
                },
                totalCalories: {
                  type: Type.NUMBER,
                  description: "Total calories for the day per person",
                },
                meals: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: {
                        type: Type.STRING,
                        description: "Unique ID for the meal",
                      },
                      name: {
                        type: Type.STRING,
                        description: "Name of the dish",
                      },
                      type: {
                        type: Type.STRING,
                        description: "breakfast, lunch, dinner, or snack",
                      },
                      description: {
                        type: Type.STRING,
                        description: "Short appetizing description",
                      },
                      ingredients: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            name: { type: Type.STRING },
                            amount: {
                              type: Type.STRING,
                              description:
                                "Amount scaled for the total servings",
                            },
                            isSeasonal: {
                              type: Type.BOOLEAN,
                              description:
                                "True if this is a local seasonal ingredient",
                            },
                            isLocal: {
                              type: Type.BOOLEAN,
                              description: "True if this is a local specialty",
                            },
                          },
                          required: ["name", "amount"],
                        },
                      },
                      instructions: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "Step by step cooking instructions",
                      },
                      calories: {
                        type: Type.NUMBER,
                        description: "Calories per serving",
                      },
                      protein: {
                        type: Type.NUMBER,
                        description: "Protein in grams per serving",
                      },
                      carbs: {
                        type: Type.NUMBER,
                        description: "Carbs in grams per serving",
                      },
                      fat: {
                        type: Type.NUMBER,
                        description: "Fat in grams per serving",
                      },
                      prepTime: {
                        type: Type.NUMBER,
                        description: "Preparation and cooking time in minutes",
                      },
                      servings: {
                        type: Type.NUMBER,
                        description: `Should be ${totalPeople}`,
                      },
                    },
                    required: [
                      "id",
                      "name",
                      "type",
                      "description",
                      "ingredients",
                      "instructions",
                      "calories",
                      "protein",
                      "carbs",
                      "fat",
                      "prepTime",
                      "servings",
                    ],
                  },
                },
              },
              required: ["date", "totalCalories", "meals"],
            },
          },
        },
        required: ["title", "days"],
      },
    },
  });

  const data = JSON.parse(response.text || "{}");

  return {
    id: crypto.randomUUID(),
    title: data.title || "Your Custom Diet Plan",
    createdAt: new Date().toISOString(),
    type: planType,
    days: data.days || [],
  };
}
